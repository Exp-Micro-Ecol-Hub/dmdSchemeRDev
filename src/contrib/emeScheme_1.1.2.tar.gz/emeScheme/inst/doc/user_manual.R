## ---- eval = FALSE------------------------------------------------------------
#  ## install the devtools package if not installed yet.
#  ## It is needed for installing the `emeScheme` package
#  
#  ## install.packages("devtools")
#  
#  ## install the `dmdScheme` package fron CRAN
#  
#  install.packages("dmdScheme")
#  
#  ## you can also install it from github
#  
#  # devtools::install_github("Exp-Micro-Ecol-Hub/dmdScheme", ref = "master", build_opts = c("--no-resave-data"))

## ----eval = FALSE, echo = TRUE------------------------------------------------
#  library("dmdScheme")
#  
#  scheme_install(	name = "emeScheme", version = "0.9.5", install_package = TRUE)

## ----eval = TRUE, echo = TRUE-------------------------------------------------
library(emeScheme)

## ----eval = FALSE, echo = TRUE------------------------------------------------
#  cache(createPermanent = TRUE)

## ----eval=FALSE---------------------------------------------------------------
#  open_new_spreadsheet()

## ----eval=FALSE---------------------------------------------------------------
#  open_new_spreadsheet(keepData = TRUE)
#  # open_new_spreadsheet(keepData = TRUE, format = FALSE)

## -----------------------------------------------------------------------------
make_example()

## ----eval = FALSE-------------------------------------------------------------
#  make_example("basic")

## ----eval = FALSE-------------------------------------------------------------
#  report("thenameofyourmetadataspreadsheet.xlsx", path = "the/path/to/your/datafiles", report = "html")

## ----eval=FALSE---------------------------------------------------------------
#  write_xml( read_excel("thenameofyourmetadataspreadsheet.xlsx", file = "thenameofyourmetadataspreadsheet.xlm")

## ----eval=FALSE---------------------------------------------------------------
#  saveRDS( x = read_excel("thenameofyourmetadataspreadsheet.xlsx", file = "thenameofyourmetadataspreadsheet.RDS" )

## ----eval=FALSE---------------------------------------------------------------
#  readRDS( file = "thenameofyourmetadataspreadsheet.RDS" )

